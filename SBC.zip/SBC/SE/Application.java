import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Application
{
	public static void main (String args[])
	{	
		// Lancement du mode graphique.
		Menu fen = new Menu();
	}		
}